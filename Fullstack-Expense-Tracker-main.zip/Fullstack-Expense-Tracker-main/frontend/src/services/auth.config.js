const API_BASE_URL = "http://localhost:8080/mywallet";

export default API_BASE_URL;